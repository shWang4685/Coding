function showEmpData() {
    document.write("<form action='/getAllEmpWithTM' method=post name=form1 style='display:none'>");
    document.write("</form>");
    document.form1.submit();
}